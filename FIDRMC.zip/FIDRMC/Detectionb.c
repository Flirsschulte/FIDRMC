/**************************************************************************
% Fuzzy Random Impulse Noise Detection Method for Colour Images
%
%  The paper of the FIDRMC is proposed in: 
%
%  Stefan Schulte, Val�rie De Witte, , Mike Nachtegael
%  Dietrich Van Der Weken and  Etienne E. Kerre:
%  A Fuzzy Two-step Filter for Impulse Noise Reduction From Colour Images,
%  IEEE Transactions on Image Processing 15(11), 2006, 3567 - 3578
%  
% Stefan Schulte (stefan.schulte@Ugent.be):
% Last modified: 30/05/06
%**************************************************************************/

#include "mex.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

double LARGE (double x, double p1, double p2) {
   double res = 0.0;
   if ((x > p1) && (x < p2))   res = (x-p1)/(p2-p1);
   else if (x > p2)            res = 1.0;
   else                        res = 0.0;
   return res;
}

double SIM (double x, double a, double b) {
   double res = 0.0, y = 0.0, z = 0.0;
   y = maximum(minimum(1-x,1-a), minimum(1-x,1-b));
   z = maximum(minimum(x,a),minimum(x,b));
   res = maximum(y,z);
   return res;
}

double absol(double a) {
   double b;
   if(a<0)   b=-a;
   else   b=a;
   return b;
}

double minimum(double a, double b) {
   double x;
   if(a<=b)   x = a;
   else   x=b;
   return x;
}

double maximum(double a, double b) {
   double x;
   if(a<=b)   x = b;
   else   x=a;
   return x;
}

/**************************************************************************************
*  The main program of the FIDRMC method
****************************************************************************************/
void callMemb(double **A1,double *mem,double a, double b,int M, int N) { 
   int i,j,k, loop;   
   double *med, *histo,*sorted,*maxi;
   double som, tel, hlp,res, tmp, slope1, diff1, diff2, diff3;
   double l1, l2, l3, minslop1, minslop2, slope2;
   int **xy, **adj;

   int rand1a = 0;
   int rand1b = 0;
   int rand2a = 0;
   int rand2b = 0;
   
   xy = malloc(9*sizeof(int));
   adj = malloc(9*sizeof(int));
   for(i=0;i<9;i++){
      xy[i] = malloc(2*sizeof(int));
      adj[i] = malloc(2*sizeof(int));
   }
   
   med = malloc(8*sizeof(double));
      
   xy[0][0] = -1; xy[0][1] = -1; xy[1][0] = -1; xy[1][1] = 0; 
   xy[2][0] = -1; xy[2][1] =  1; xy[3][0] =  0; xy[3][1] = -1; 
   xy[4][0] =  0; xy[4][1] =  0; xy[5][0] =  0; xy[5][1] = 1; 
   xy[6][0] =  1; xy[6][1] = -1; xy[7][0] =  1; xy[7][1] = 0; 
   xy[8][0] =  1; xy[8][1] =  1; 

   adj[0][0] = 1; adj[0][1] = -1; adj[1][0] =  0; adj[1][1] = -1; 
   adj[2][0] = 1; adj[2][1] =  1; adj[3][0] =  1; adj[3][1] =  0; 
   adj[4][0] = 0; adj[4][1] =  0; adj[5][0] =  1; adj[5][1] =  0; 
   adj[6][0] = 1; adj[6][1] =  1; adj[7][0] =  0; adj[7][1] = -1; 
   adj[8][0] = 1; adj[8][1] = -1; 
               
      
   for(i=2; i<M-2; i++){
      for(j=2; j<N-2; j++){
         /*--------------------------------------------
                Gradient values method
         --------------------------------------------*/
         tel = 0;
         for (k = 0; k<9; k++){
            if (k==4) continue;
            diff1 = A1[i+xy[k][1]][j+xy[k][0]] - A1[i][j];
            diff2 = A1[i+xy[k][1]+adj[k][1]][j+xy[k][0]+adj[k][0]] - A1[i+adj[k][1]][j+adj[k][0]];
            diff3 = A1[i+xy[k][1]-adj[k][1]][j+xy[k][0]-adj[k][0]] - A1[i-adj[k][1]][j-adj[k][0]];
            
            l1 = LARGE(absol(diff1),a,b);
            l2 = LARGE(absol(diff2),a,b);
            l3 = LARGE(absol(diff3),a,b);
            
            res = 1.0-  maximum( maximum(minimum(1-l1,1-l2), minimum(1-l1,1-l3)), maximum(minimum(l1,l2),minimum(l1,l3)));
            res = l1*res;
            for (loop = 0; loop<tel; loop++){
                if (res < med[loop]){
                   hlp = med[loop];
                   med[loop] = res;
                   res = hlp;
                }
            }
            med[(int)tel] = res;
            tel++;
         }
         mem[i+j*M] = minimum( minimum(med[6],med[7]),med[5]);
      }
   }

   for(i=0;i<9;i++)  free(xy[i]);
   free(xy); 
   for(i=0;i<9;i++)  free(adj[i]);
   free(adj); 
   free(med); 
} 


#define Im1      prhs[0]
#define PAR1     prhs[1]
#define PAR2     prhs[2]
#define OUT plhs[0]

/**
*  The interaction with Matlab (mex):
*        nlhs = amount of output arguments (= 1)
*        nrhs = amount of input arguments (= 3)
*     *plhs[] = link to the output 
*     *prhs[] = link to the input 
*
**/
void mexFunction( int nlhs, mxArray  *plhs[], int nrhs, const mxArray  *prhs[] ) {
    int row, col, i, M, N;
    double **mem, **A1, p1, p2;
    
    if (nlhs!=1)
        mexErrMsgTxt("It requires one output arguments only [M1].");
    if (nrhs!=3)
       mexErrMsgTxt("this method requires three input argument [Im1]");

    /* Get input values */  
    M = mxGetM(Im1);
    N = mxGetN(Im1);
    p1 = mxGetScalar(PAR2);
    p2 = mxGetScalar(PAR1);

    /**
    * Allocate memory for return matrices 
    **/
    OUT = mxCreateDoubleMatrix(M, N, mxREAL);  
    mem = mxGetPr(OUT);

    /**
    * Dynamic allocation of memory for the input array
    **/
    A1 = malloc(M*sizeof(int));
    for(i=0;i<M;i++)
      A1[i] = malloc(N*sizeof(double));

     /**
     * Convert ARRAY_IN and INPUT_MASK to 2x2 C arrays (MATLAB stores a two-dimensional matrix 
     * in memory as a one-dimensional array) 
     ***/
     for (col=0; col < N; col++)
         for (row=0; row < M; row++) {
             A1[row][col] = (mxGetPr(Im1))[row+col*M];
	      }
	      
	      
    /* Call the main program */ 
    callMemb(A1,mem,p1,p2,M,N);

    for(i=0;i<M;i++)  free(A1[i]);
    free(A1); 
}
/* end mexFcn*/